# GENERATED VERSION FILE
# TIME: Thu Jan 21 12:06:57 2021

__version__ = '0.3.0+4d58914'
short_version = '0.3.0'
